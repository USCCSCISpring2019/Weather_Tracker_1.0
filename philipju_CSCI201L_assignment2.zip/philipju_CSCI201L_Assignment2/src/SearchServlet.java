

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import csci201.City;


@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String searchType = request.getParameter("searchType");
		ArrayList<City> cityList = (ArrayList<City>)request.getSession().getAttribute("index");
		if (searchType.equals("a")) {
			String citySearchName = (String)request.getParameter("citySearchName");
			System.out.println("city search type");
			for (City city : cityList) {
				if (city.getCity().equalsIgnoreCase(citySearchName)) {
					request.setAttribute("cityObject", city);
				}
			}
			request.getRequestDispatcher("displaysearch.jsp").forward(request, response);
		}
		else {
			String latSearch = (String)request.getParameter("latSearch");
			String longSearch = (String)request.getParameter("longSearch");
			for (City city : cityList) {
				if (city.getLatitude().equals(latSearch) && city.getLongitude().equals(longSearch)) {
					request.setAttribute("cityObject", city);
				}
			}
			request.getRequestDispatcher("displaysearch.jsp").forward(request, response);
		}
		
	}

	

}
