package csci201;

public class City  {
	
	/*
	 * city|state|country|latitude|longitude|sunrise|sunset|currentTemp
erature|dayLow|dayHigh|humidity|pressure|visibility|windSpeed|wi
ndDirection|conditionDescription1|conditionDescription2|...|cond
itionDescriptionN

	 */
	
	private String city;
	private String state;
	private String country;
	private double latitude;
	private double longitude;
	private String sunriseTime;
	private String sunsetTime;
	
	private int currentTemperature;
	private int dayLow;
	private int dayHigh;
	private int humidity;
	private float pressure;
	private float visibility;
	private float windspeed;
	private int windDirection;
	private String[] conditionDescription;
	
	
	// Constructor that takes an array of Strings as arg
	public City(String[] cityInfo) throws MyException {
		city = cityInfo[0];
		state = cityInfo[1];
		country = cityInfo[2];
		latitude = myDoubleParser(cityInfo[3]);
		longitude = myDoubleParser(cityInfo[4]);
		sunriseTime = myTimeChecker(cityInfo[5]);
		sunsetTime = myTimeChecker(cityInfo[6]);
		currentTemperature = myIntParser(cityInfo[7]);
		dayLow = myIntParser(cityInfo[8]);
		dayHigh = myIntParser(cityInfo[9]);
		humidity = myIntParser(cityInfo[10]);
		pressure = myFloatParser(cityInfo[11]);
		visibility = myFloatParser(cityInfo[12]);
		windspeed = myFloatParser(cityInfo[13]);
		windDirection = myIntParser(cityInfo[14]);
		conditionDescription = new String[ cityInfo.length - 15 ];
		for (int i = 15; i < cityInfo.length; i++) {
			conditionDescription[i - 15] = myDescriptionParser(cityInfo[i]);
		}
	}
	public String getCity() {
		return city;
	}
	public String getState() {
		return state;
	}
	public String getCountry() {
		return country;
	}
	public String getLatitude() {
		String latStr = String.format("%.4f", latitude);
		return latStr;
	}
	public String getLongitude() {
		String lonStr = String.format("%.4f", longitude);
		return lonStr;
	}
	public String getSunriseTime() {
		return sunriseTime;
	}
	public String getSunsetTime() {
		return sunsetTime;
	}
	public int getCurrentTemperature() {
		return currentTemperature;
	}
	public int getDayLow() {
		return dayLow;
	}
	public int getDayHigh() {
		return dayHigh;
	}
	public int getHumidity() {
		return humidity;
	}
	public float getPressure() {
		return pressure;
	}
	public float getVisibility() {
		return visibility;
	}
	public float getWindspeed() {
		return windspeed;
	}
	public int getWindDirection() {
		return windDirection;
	}
	public String[] getConditionDescription() {
		return conditionDescription;
	}
	
	private static String myTimeChecker(String arg) throws MyException {
		String[] timeComponents = arg.split("[: ]");
		try {
			int hour = Integer.parseInt(timeComponents[0]);
			if (hour > 12 || hour < 1) 
				throw new MyException();
			int minutes = Integer.parseInt(timeComponents[1]);
			if (minutes > 60 || minutes < 0) 
				throw new MyException();
			if (!timeComponents[2].equalsIgnoreCase("am") && !timeComponents[2].equalsIgnoreCase("pm")) {
				throw new MyException();
			}
		} catch (Exception e) {
			throw new MyException();
		}
		return arg;
	}
	
	
	private static double myDoubleParser(String arg) throws MyException {
		double coord;
		try {
			coord = Double.parseDouble(arg);
		}
		catch (NumberFormatException e) {
			throw new MyException(arg, "double");
		}
		return coord;
	}
	
	
	private static int myIntParser(String arg) throws MyException {
		int temp;
		try {
			temp = Integer.parseInt(arg);
		}
		catch (NumberFormatException e) {
			throw new MyException(arg, "integer");
		}
		return temp;
	}
	private static float myFloatParser(String arg) throws MyException {
		float temp;
		try {
			temp = Float.parseFloat(arg);
		}
		catch (NumberFormatException e) {
			throw new MyException(arg, "float");
		}
		return temp;
	}
	
	// Just don't want only white-space strings from being entered into description
	private static String myDescriptionParser(String arg) throws MyException{
		if (arg.trim().length() == 0) throw new MyException(arg, "string");
		return arg;
	}
}
	
