package csci201;
import java.util.Scanner;	// for Scanner class
import java.io.*;	// for File class and FileNotFoundException
import java.util.ArrayList; // needed for ArrayList class


public class ReadFile {
	public static boolean read(ArrayList<City> cityList, String fileName) {
		
		
		try {
			File file = new File(fileName);
			Scanner inputFile = new Scanner(file);
			// if file found, continue execution of code here
			while (inputFile.hasNext()) {
				String text = inputFile.nextLine();
				String[] cityInfo = text.split("\\|");
				
	
				if (cityInfo.length < 10) {
					// Needs at least 10 categories
					// Print out error message
					System.out.print("There are not enough parameters on line ");
					System.out.println("'" + text + "'.");
					System.out.println("");
					inputFile.close();
					return false;
				}
				
				// Will store a list of cities in ArrayList so we can
				//   dynamically change the size of it (adding).
				
				try {
					City nextCity = new City(cityInfo);
					// if we are able to create this new city, continue execution of code here
					cityList.add(nextCity);
				}
				catch (MyException e) {
					// Print out error message
					System.out.println("This file " + fileName + " is not formatted properly.");
					System.out.println(e.getMessage());
					System.out.println("");
					inputFile.close();
					return false;
				}
			}
			inputFile.close();
			return true;
		}
		catch (FileNotFoundException e) {
			System.out.println("The file " + fileName + " could not be found.");
			System.out.println("");
			return false;
		}
	}
}
