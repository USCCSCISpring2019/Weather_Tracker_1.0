

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import csci201.City;


@WebServlet("/CityServlet")
public class CityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cityName_ = request.getParameter("cityName_");
		ArrayList<City> cityList = (ArrayList<City>)request.getSession().getAttribute("index");
		for (City city : cityList) {
			if (city.getCity().equalsIgnoreCase(cityName_)) {
				request.setAttribute("cityInfoObject", city);
			}
		}
		request.getRequestDispatcher("cityinfo.jsp").forward(request, response);
		
	}

}
